<?php
/**
 * Exception class.
 *
 * @author  Michael Aichler <aichler@mediacluster.de>
 * @version $Revision: 1.3 $
 * @package creole.exception
 */
class __Exception
{
  var $code;
  var $message;
  var $context;

  var $class;
  var $file;
  var $line;
  var $method;

  // debug backtrace
  var $backtrace;

  function __Exception($message, $code = 0, $backtrace = null)
  {
      $this->code = $code;
      $this->message = $message;
      $this->backtrace = debug_backtrace();

      $bc = $this->backtrace[count($this->backtrace)-1];
      $this->file = @$bc['file'];
      $this->line = @$bc['line'];
      $this->class = @$bc['class'];
      $this->method= @$bc['function'];

      //Trigger_error($this->toString(), E_USER_NOTICE);
      //Trigger_error($this->toString(), E_USER_ERROR);
	  Trigger_error($this->__ErrorHandler(E_ERROR, $this->message , $this->file , $this->line));
	  //Trigger_error($this->assignError(), ErrorHandler::ERROR());
  }

  function getMessage()
  {
    return $this->message;
  }

  function getCode()
  {
    return $this->code;
  }

  /**
   * Returns a string representation fitting for debug output.
   *
   * @return  string  String representation of the exception
   * @author  manuel holtgrewe <purestorm at teforge dot org>
   * @access  public
   */
  function toString()
  {
    $result = "[Exception, message=\"" . $this->message . "\", " .
              "code=\"" . $this->code. "\", " .
              "file=\"" . $this->file . "\", " .
              "line=\"" . $this->line . "\"]";
    return $result;
  }

  /**
   * @author  alex black, [email]enigma@turingstudio.com[/email]
   * @access  public
   */
  function getFile()
  {
    return $this->file;
  }

  function getLine()
  {
    return $this->line;
  }

  function getContext($html = false)
  {
    $str = ($html ? "<h3>[Context]</h3>\n" : "[Context]\n");

    if (! file_exists($this->file)) {
      $str .= "Context cannot be shown - ($this->file) does not exist\n";
      return $str;
    }
    if ((! is_int($this->line)) || ($this->line <= 0)) {
      $str .= "Context cannot be shown - ($this->line) is an invalid line number";
      return $str;
    }

    $lines = file($this->file);
    //  get the source ## core dump in windows, scrap colour highlighting :-(
    //  $source = highlight_file($this->file, true);
    //  $this->lines = split("<br />", $source);
    //  get line numbers
    $start = $this->line - 6; // -1 including error line
    $finish = $this->line + 5;
    //  get lines
    if ($start < 0) {
        $start = 0;
    }
    if ($start >= count($lines)) {
        $start = count($lines) -1;
    }
    for ($i = $start; $i < $finish; $i++) {
        //  highlight line in question
        if ($i == ($this->line -1)) {
            $context_lines[] = '<font color="red"><b>' . ($i + 1) .
                "\t" . strip_tags($lines[$this->line -1]) . '</b></font>';
        } else {
            $context_lines[] = '<font color="black"><b>' . ($i + 1) .
                "</b></font>\t" . @$lines[$i];
        }
    }

    $str .= trim(join("<br />\n", $context_lines)) . "<br />\n";
    return $str;
  }

	function getBacktrace($html = false)
	{
	$str = ($html ? "<h3>[Backtrace]</h3>\n" : "[Backtrace]\n");

	foreach($this->backtrace as $bc)
	{
	  if (isset($bc['class'])) {
		$s = ($html ? "<b>%s</b>" : "%s") . "::";
		$str .= sprintf($s, $bc['class']);
	  }
	  if (isset($bc['function'])) {
		$s = ($html ? "<b>%s</b>" : "%s");
		$str .= sprintf($s, $bc['function']);
	  }

	  $str .= ' (';

	  if (isset($bc['args']))
	  {
		foreach($bc['args'] as $arg)
		{
		  $s = ($html ? "<i>%s</i>, " : "%s, ");
		  $str .= sprintf($s, gettype($arg));
		}
		$str = substr($str, 0, -2);
	  }

	  $str .= ')';
	  $str .= ': ';
	  $str .= '[ ';
	  if (isset($bc['file'])) {
		$dir = substr(dirname($bc['file']), strrpos(dirname($bc['file']), '/') + 1);
		$file = basename($bc['file']);
		if ($html) $str .= "<a href=\"file:/" . $bc['file'] . "\">";
		$str .= $dir . '/' . $file;
		if ($html) $str .= "</a>";
	  }
	  $str .= isset($bc['line']) ? ', ' . $bc['line'] : '';
	  $str .= ' ] ';
	  $str .= ($html ? "<br />\n" : "\n");
    }

    return $str;
}
  

	var $errorStack = array();
	var $wasCatchCalled = false;

	function throw( &$exceptObject ) {
	  global $errorStack;

	  if (! is_object($exceptObject)) return false;

	  //get current stack level
	  $idx = count($errorStack);
	  if ($idx) $idx--;

	  //add exception
	  $errorStack[ $idx ][] = $exceptObject;

	  return true;
	}


	function _try() {
	  global $errorStack, $wasCatchCalled;

	  //get current stack level
	  $idx = count( $errorStack );

	  //check if it's a nested try() or not
	  if ($idx && $wasCatchCalled) {
	      //new block so reuse the old one
	      $idx--;
	      //!!! should I unset each exception object???
	      unset($GLOBALS['errorStack'][$idx]);
	      $wasCatchCalled = false;

	  }

	  $errorStack[$idx] = array();

	  return true; //always returns true!
	}


	function catch( $exceptType, &$exceptObject, $pass = true ) {
	  global $errorStack, $wasCatchCalled;

	  $wasCatchCalled = true;

	  //get current stack level
	  $idx = count($errorStack);
	  if ($idx) $idx--;

	  $found = false;
	  $exceptType = strtolower($exceptType);
	  reset($errorStack[$idx]);
	  for ($i=0; $i<count($errorStack[$idx]); $i++) {

	    if ( 'exception' === $exceptType ||
	         $exceptType === get_class($errorStack[$idx][$i]) ) {

	      //return the exception object
	      $exceptObject = $errorStack[$idx][$i];

	      //remove the exception from the stack
	      if ('exception' !== $exceptType) {
	        array_splice( $errorStack[$idx], $i, 1 );
	      } else {
	        $errorStack[$idx] = array();
	      }

	      $found = true;
	      break;
	    }
	  }

	  //copy the other exceptions one level down
	  if ($idx && $pass ) {
	    $errorStack[$idx-1] = array_merge( $errorStack[$idx-1], $errorStack[$idx] );
	    unset($GLOBALS['errorStack'][$idx]);
	  }

	  return $found;
	}

	function hasExceptions() {
	  global $errorStack;

	  //get current stack level
	  $idx = count($errorStack);
	  if ($idx) $idx--;

	  return (boolean) count($errorStack[$idx]);
	}


	//=============================================================
	// error handler function
	function __ErrorHandler ($errno, $errstr, $errfile, $errline) {
		$s = '';
		//echo $errstr;
		switch ($errno) {
			case E_PARSE: $s = 'Parse error'; break;
			case E_WARNING:
				if (strpos($errstr, 'REG_') !== false) $s = "ERROR: $errstr"; // incorrect POSIX regexp
				break;
			case E_ERROR:
			case E_USER_NOTICE:
				$s = "<br/><b>ERROR : </b> $errstr (in file $errfile line $errline)";
				
				break;
		}
		
		echo $s;

	}

}

?>